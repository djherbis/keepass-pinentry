All projects contain dummy PFX files. These PFX files are NOT
the ones with which the KeePass distributions are signed, these
are kept secret.

In order to unlock the private keys of the dummy PFX files,
use:

    "123123"  (without the quotes)


Official KeePass distributions are signed with private keys.
You can find the corresponding public keys in the

    Ext/PublicKeys
    
directory.
